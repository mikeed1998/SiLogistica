@extends('layouts.app')

@section('title', 'Home')

@section('extracss')
    
@endsection

@section('content')
    
@endsection

@section('scripts')
    
@endsection


