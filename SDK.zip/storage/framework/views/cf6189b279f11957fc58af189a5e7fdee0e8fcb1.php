<?php $__env->startSection('extraCSS'); ?>
    <style>

        body { background-color: #e5e8eb  !important; }

        .card-header { background-color: #b0c1d1  !important; }

        .black-skin
        .btn-primary { background-color: #b0c1d1  !important; }

        .btn {
            box-shadow: none;
            border-radius: 15px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row mt-5 mb-4 px-2">
        <div class="col-6 text-start">
            <a href="<?php echo e(route('front.admin')); ?>" class="mt-5 w-50 col col-md-2 btn btn-sm btn-dark mr-auto"><i class="fa fa-reply"></i> Regresar</a>
        </div>
        <div class="col-6 text-end">
            <a href="<?php echo e(route('faqs.create')); ?>" class="mt-5 w-50 col col-md-2 btn btn-sm btn-success text-white"><i class="fa fa-plus"></i> Agregar</a>
        </div>
    </div>

    <div class="accordion sortable" data-table="Faq" id="acordionfaqs">
		<?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" data-card="<?php echo e($f->id); ?>">
                <div class="row">
                    <div class="col-9">
                        <a href="<?php echo e(route('faqs.show', ['id' => $f->id])); ?>" class="btn btn-link btn-block py-0 text-left fs-5" >
							<?php echo e($f->pregunta); ?>

						</a>
                    </div>
                    <div class="col-3">
                        <div class="row">
                            <div class="col-6">
                                <a href="<?php echo e(route('faqs.edit', ['id' => $f->id])); ?>" class="btn btn-sm btn-info text-right w-100 rounded-0">
                                    <i class="bi bi-pencil-square fs-5"></i>
                                </a>
                            </div>
                            <div class="col-6">
                                <button class="btn btn-sm btn-danger text-right w-100 rounded-0" data-toggle="modal" data-target="#frameModalDel" data-id="<?php echo e($f->id); ?>">
                                    <i class="bi bi-trash fs-5"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<div class="card mb-3" data-card="<?php echo e($f->id); ?>">

				<div id="collapse<?php echo e($f->id); ?>" class="collapse" aria-labelledby="heading<?php echo e($f->id); ?>" data-parent="#acordionfaqs">
					<div class="card-body text-justify">
						<?php echo $f->respuesta; ?>

					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

	<div class="modal fade bottom" id="frameModalDel" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-frame modal-top" role="document">
			<div class="modal-content">
				<div class="modal-body">
					<div class="row d-flex justify-content-center align-items-center">
						<p class="pt-3 pr-2">
							Eliminar Pregunta?
						</p>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
						<button type="button" class="btn red darken-3 text-white delslide">Eliminar</button>
						<form id="preguntadel" action="<?php echo e(route('faqs.destroy', ['faq' => 1])); ?>" method="POST" style="display: none;">
								<?php echo csrf_field(); ?>
								 <?php echo method_field('delete'); ?>
								<input type="hidden" id="iqdel" name="pregunta" value="">
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extraJS'); ?>
<script type="text/javascript">
    $(document).ready(function() {

        $('.fa-trash-alt').parent().click(function(e) {
            var id = $(this).attr('data-id');
            $("#iqdel").val(id);
        });

        $('.delslide').click(function(e) {
            $('#preguntadel').submit();
        });

    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\SiLogistica\resources\views/config/faqs/index.blade.php ENDPATH**/ ?>