<?php $__env->startSection('extraCSS'); ?>
    <style>

        body { background-color: #e5e8eb  !important; }

        .card-header { background-color: #b0c1d1  !important; }

        .black-skin
        .btn-primary { background-color: #b0c1d1  !important; }

        .btn {
            box-shadow: none;
            border-radius: 15px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row mt-5 mb-4 px-2">
        <a href="<?php echo e(route('front.admin')); ?>" class="mt-5 col col-md-2 btn btn-sm btn-dark mr-auto"><i class="fa fa-reply"></i> Regresar</a>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col display-5 text-center fw-bolder">
                Servicios   
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-6 mx-auto">
                <a href="<?php echo e(route('servicio.servicio.create')); ?>" class="btn btn-dark w-100">Crear nuevo</a>
            </div>
        </div>
        <div class="row mt-5">
            <?php $__empty_1 = true; $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-12">
                    <div class="card">
                        <div class="row">
                            <div class="col-2">
                                <img src="<?php echo e(asset('img/photos/servicios/'.$serv->portada)); ?>" alt="" class="img-fluid" style="height: 100px;">
                            </div>
                            <div class="col-8">
                                <div class="row d-flex align-items-center justify-content-center h-100">
                                    <div class="col-8 d-flex align-items-center justify-content-center h-100">
                                        <div class="card-title"><?php echo e($serv->titulo); ?></div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-check form-switch">
                                            <label for="switch_inicio-<?php echo e($serv->id); ?>" class="form-control-label fw-bolder py-2">Mostrar en inicio</label>
                                            <input class="form-check-input switch-color-inicio shadow-none fs-2" role="switch" id="switch_inicio-<?php echo e($serv->id); ?>" data-id="<?php echo e($serv->id); ?>" data-campo="inicio" type="checkbox" <?php if($serv->inicio == 1): ?> checked <?php endif; ?>>
                                        </div>
                                        <script>
                                            $('#switch_inicio-'+<?php echo e($serv->id); ?>).change(function (e){
                                                var checkbox = $(this);
                                                console.log('switch-'+<?php echo e($serv->id); ?>);
                                                var check = 0;
                                                if (checkbox.prop('checked')) {
                                                    check = 1;
                                                } else {
                                                    check = 2;
                                                }
                                                console.log(check);
                                                var id = checkbox.attr("data-id");
                                                var tcsrf = $('meta[name="csrf-token"]').attr('content');
                                                var valor = check;
                                                var URL = "<?php echo e(route('ajax.switch_inicio')); ?>";
                                                console.log("valor: " + valor);
                                                $.ajax({
                                                    url: URL,
                                                    type: 'post',
                                                    dataType: 'json',
                                                    data: {
                                                        "_method": 'post',
                                                        "_token": tcsrf,
                                                        "id": id,
                                                        "valor": valor
                                                    }
                                                })
                                                .done(function(msg) {
                                                    console.log(msg);
                                                    if (msg.success) {
                                                        toastr["info"](msg.mensaje);
                                                        if (msg.mensaje.valor == 1) {
                                                            checkbox.prop('checked', true);
                                                        } else if (msg.mensaje.valor == 2) {
                                                            checkbox.prop('checked', false);
                                                        }
                                                    } else {
                                                        toastr["error"](msg.mensaje);
                                                    }
                                                })
                                                .fail(function(msg) {
                                                    toastr["error"]('Error al agregar el serv al inicio');
                                                });
                                            });
                                        </script>
                                    </div>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="row">
                                    <div class="col-12">
                                        <button type="button" class="btn btn-dark w-100 rounded-0" data-bs-toggle="modal" data-bs-target="#staticBackdrop-<?php echo e($serv->id); ?>"><i class="bi bi-eye"></i> Detalle</button>
                                        <div class="modal fade" id="staticBackdrop-<?php echo e($serv->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel-<?php echo e($serv->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog modal-xl">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="staticBackdropLabel-<?php echo e($serv->id); ?>">Detalle del servicio: <?php echo e($serv->titulo); ?></h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <?php echo $serv->descripcion; ?>

                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger w-100 rounded-0" data-bs-dismiss="modal">Cerrar detalles</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <a href="<?php echo e(route('servicio.servicio.edit', ['servicio' => $serv->id])); ?>" class="btn btn-info w-100 rounded-0"><i class="bi bi-book"></i> Editar</a>
                                    </div>
                                    <div class="col-12">
                                        <form action="<?php echo e(route('servicio.servicio.destroy', ['servicio' => $serv->id])); ?>" method="POST" enctype="multipart/form-data" class="delete-form" id="form-<?php echo e($serv->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger w-100 rounded-0"><i class="bi bi-trash"></i> Eliminar</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
             
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div>
                    No hay servicios
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extraJS'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const forms = document.querySelectorAll('.delete-form');

            forms.forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    event.preventDefault();
                    Swal.fire({
                        title: '¿Estás seguro?',
                        text: "¡No podrás revertir esto!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sí, eliminar!',
                        cancelButtonText: 'Cancelar'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            form.submit();
                        }
                    });
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\SiLogistica\resources\views/config/secciones/servicios.blade.php ENDPATH**/ ?>